
from django.urls import path
from .views import ClassViewTemplate, function_view_template

urlpatterns = [
    path('class-view/', ClassViewTemplate.as_view(), name='class_view'),
    path('function-view/', function_view_template, name='function_view'),
]
