
# from django.views.generic import TemplateView
#
# class ClassViewTemplate(TemplateView):
#     template_name = 'second_task/class_view_template.html'
#
# def function_view_template(request):
#     return TemplateView.as_view(template_name='second_task/function_view_template.html')(request)
#
from django.shortcuts import render
from django.views.generic import TemplateView

# Функциональное представление
def function_view_template(request):
    return render(request, 'second_task/function_view_template.html')

# Классовое представление
class ClassViewTemplate(TemplateView):
    template_name = 'second_task/class_view_template.html'